import developer from './developer'
import payments from './payments'
const admin = {
    developer: Object.assign(developer, developer),
payments: Object.assign(payments, payments),
}

export default admin